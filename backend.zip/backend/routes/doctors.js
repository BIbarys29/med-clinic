const express = require('express');
const router = express.Router();
const Doctor = require('../models/Doctor');
const auth = require('../middleware/auth');

router.get('/', async (req, res) => {
  try {
    const doctors = await Doctor.find();
    res.json(doctors);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

router.post('/', auth, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ msg: 'Access denied' });
  try {
    const newDoctor = new Doctor(req.body);
    const doctor = await newDoctor.save();
    res.json(doctor);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

router.put('/:id/schedule', auth, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ msg: 'Access denied' });
  try {
    const doctor = await Doctor.findByIdAndUpdate(
      req.params.id,
      { $push: { schedule: req.body } },
      { new: true }
    );
    res.json(doctor);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

module.exports = router;