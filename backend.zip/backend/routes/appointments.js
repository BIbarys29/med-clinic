const express = require('express');
const router = express.Router();
const Appointment = require('../models/Appointment');
const auth = require('../middleware/auth');

router.post('/', auth, async (req, res) => {
  try {
    const { doctorId, date, notes } = req.body;
    const newAppointment = new Appointment({
      patient: req.user.id,
      doctor: doctorId,
      date,
      notes
    });
    const appointment = await newAppointment.save();
    res.json(appointment);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

router.get('/', auth, async (req, res) => {
  try {
    const appointments = await Appointment.find({ patient: req.user.id })
      .populate('doctor', 'name specialization');
    res.json(appointments);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

router.patch('/:id/cancel', auth, async (req, res) => {
  try {
    const appointment = await Appointment.findOneAndUpdate(
      { _id: req.params.id, patient: req.user.id },
      { 
        $set: { status: 'cancelled' },
        $set: { cancellationReason: req.body.reason }
      },
      { new: true }
    );
    res.json(appointment);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

module.exports = router;