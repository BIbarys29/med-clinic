const mongoose = require('mongoose');

const DoctorSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  specialization: {
    type: String,
    required: true,
    index: true 
  },
  experience: {
    type: Number,
    required: true
  },
  rating: {
    type: Number,
    default: 0
  },
  schedule: [{
    day: String,
    startTime: String,
    endTime: String,
    isAvailable: { type: Boolean, default: true }
  }]
});

DoctorSchema.index({ name: 1, specialization: 1 }); 

module.exports = mongoose.model('Doctor', DoctorSchema);