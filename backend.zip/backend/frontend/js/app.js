const API_URL = 'http://localhost:5000/api';

console.log('App.js loaded!');

function checkAuth() {
    const token = localStorage.getItem('token');
    const publicPages = ['login.html', 'register.html', 'index.html', 'doctors.html'];
    const currentPage = window.location.pathname.split('/').pop();

    if (!token && !publicPages.includes(currentPage)) {
        window.location.href = 'login.html';
    }
    updateNav();
}

function updateNav() {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    const navAuth = document.getElementById('nav-auth');
    
    if (navAuth) {
        if (token) {
            let links = `
                <li class="nav-item"><a class="nav-link" href="dashboard.html">Appointments</a></li>
                <li class="nav-item"><a class="nav-link" href="history.html">Medical History</a></li>
            `;
            
            if (role === 'admin') {
                links += `<li class="nav-item"><a class="nav-link" href="admin.html">Admin Panel</a></li>`;
            }

            links += `<li class="nav-item"><a class="nav-link" href="#" onclick="logout()">Logout</a></li>`;
            navAuth.innerHTML = links;
        } else {
            navAuth.innerHTML = `
                <li class="nav-item"><a class="nav-link" href="login.html">Login</a></li>
                <li class="nav-item"><a class="nav-link" href="register.html">Register</a></li>
            `;
        }
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    window.location.href = 'login.html';
}

async function apiRequest(endpoint, method = 'GET', body = null) {
    const token = localStorage.getItem('token');
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['x-auth-token'] = token;

    const config = { method, headers };
    if (body) config.body = JSON.stringify(body);

    try {
        const response = await fetch(`${API_URL}${endpoint}`, config);
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        alert('Server connection failed.');
    }
}